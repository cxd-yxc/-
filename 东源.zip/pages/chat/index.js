Page({
  data: {
    messages: [],
    inputContent: '',
    isTyping: false,
    scrollToMessage: '',
    scrollTop: 0 // 初始化scrollTop属性，用于手动控制滚动位置
  },

  onLoad: function() {
    // 页面加载时读取历史记录
    this.loadHistoryMessages();
  },

  // 加载历史消息
  loadHistoryMessages: function() {
    try {
      const history = wx.getStorageSync('chatHistory') || [];
      this.setData({
        messages: history
      });
      // 如果有历史消息，滚动到底部
      if (history.length > 0) {
        setTimeout(() => {
          this.setData({
            scrollToMessage: `msg-${history.length - 1}`
          });
        }, 100);
      }
    } catch (error) {
      console.error('加载历史消息失败:', error);
    }
  },

  // 保存消息到历史记录
  saveMessageToHistory: function(role, content) {
    try {
      const message = {
        role: role,
        content: content,
        timestamp: new Date().getTime()
      };
      const messages = [...this.data.messages, message];
      this.setData({
        messages: messages
      });
      wx.setStorageSync('chatHistory', messages);
    } catch (error) {
      console.error('保存消息失败:', error);
    }
  },

  // 监听输入
  onInput: function(e) {
    this.setData({
      inputContent: e.detail.value
    });
  },

  // 发送消息
  sendMessage: function() {
    const content = this.data.inputContent.trim();
    if (!content) return;
    
    // 在终端中输出处理日志
    console.log('\n[思考过程] 用户输入:', content);
    
    // 显示用户消息
    this.saveMessageToHistory('user', content);
    
    // 清空输入框
    this.setData({
      inputContent: ''
    });

    // 滚动到底部
    this.scrollToBottom();

    // 显示AI思考中
    this.setData({
      isTyping: true
    });
    
    // 创建AI回复占位符消息
    const aiMessageId = 'msg_' + Date.now();
    const aiMessage = {
      id: aiMessageId,
      role: 'ai',
      content: '',
      timestamp: new Date().getTime(),
      isStreaming: true, // 标记为流式消息
      model: null // 将存储使用的模型类型
    };
    
    // 手动添加占位符消息到消息数组
    const messages = [...this.data.messages, aiMessage];
    this.setData({ messages: messages });
    
    // 在终端中输出思考过程
    console.log('[思考过程] 收到用户问题，开始分析意图并选择合适的回复模型...');
    
    // 常见大模型风格的回复字典
    const modelResponses = {
      // GPT风格 - 详细、结构化、全面
      gpt: {
        greetings: [
          '你好！我是一个AI助手，可以帮助你解答问题、提供信息或协助完成任务。请问有什么我可以帮助你的吗？',
          '嗨！很高兴能与你交流。我是基于大语言模型开发的AI助手，请问我能为你做些什么？',
          '你好呀！欢迎提问，我会尽力为你提供准确、全面的回答。'
        ],
        thanks: [
          '不客气！能帮到你是我的荣幸。如果你还有任何其他问题，请随时告诉我。',
          '不用谢！很高兴我的回答对你有帮助。有什么其他我可以协助的吗？',
          '别客气！为你提供有用的信息是我的职责所在。'
        ],
        farewell: [
          '再见！希望我的回答能够帮助到你。如果以后有任何问题，随时欢迎你回来咨询。',
          '祝你有美好的一天！如果还有其他问题，我随时在这里等你。',
          '拜拜！很高兴能为你服务。期待下次与你交流。'
        ],
        general: [
          '基于你提出的问题，我认为可以从以下几个方面进行分析...',
          '这是一个很好的问题。让我为你详细解答：',
          '根据我的理解，你的需求可以通过以下步骤来实现...',
          '对于这个问题，我有以下几点建议：',
          '为了更好地解答你的问题，我需要考虑多个因素：'
        ],
        technical: [
          '从技术角度来看，这个问题涉及到几个关键概念...',
          '要解决这个技术挑战，可以考虑以下实现方案：',
          '这个问题的核心在于理解底层机制，我来为你拆解一下：',
          '作为开发者，我建议采用以下技术方案：',
          '根据软件工程最佳实践，我推荐：'
        ]
      },
      
      // Claude风格 - 友好、详细、有教育意义
      claude: {
        greetings: [
          '你好！我是Claude，一个由Anthropic开发的AI助手。我很乐意帮助你解答问题或提供信息。',
          '嗨！很高兴认识你。我是Claude，一个专注于诚实和有用的AI助手。有什么我可以帮助你的吗？',
          '你好呀！我是Claude，一个由AI21 Labs和Anthropic共同开发的大型语言模型。有什么问题我可以为你解答？'
        ],
        thanks: [
          '不用客气！帮助你是我的快乐。如果你有任何其他问题，我随时在这里。',
          '不客气，这是我应该做的。很高兴能为你提供帮助！',
          '别客气！希望我的回答对你有所帮助。'
        ],
        farewell: [
          '再见！希望我们的交流对你有所帮助。如果有任何后续问题，随时欢迎你回来。',
          '祝你一切顺利！有任何问题，我都会在这里为你提供帮助。',
          '拜拜！期待下次与你交流。'
        ],
        general: [
          '根据我对这个问题的理解，我认为需要考虑几个重要因素：',
          '这个问题很有趣，让我从不同角度来思考一下。首先...',
          '为了全面回答你的问题，我想先了解一下相关背景知识。',
          '关于这个话题，有几个关键点需要澄清：',
          '让我为你详细分析一下这个问题：'
        ],
        technical: [
          '从技术实现的角度来看，这个问题可以通过以下方法解决：',
          '作为一个AI助手，我可以从算法和数据结构的角度为你分析：',
          '这个技术问题涉及到几个核心原理，让我为你解释一下：',
          '要解决这个技术挑战，我们需要考虑系统架构和性能优化等多个方面：'
        ]
      },
      
      // Qwen风格 - 简洁、实用、高效
      qwen: {
        greetings: [
          '你好！我是通义千问，由阿里云开发的智能助手。有什么可以帮你的？',
          '嗨！我是千问，很高兴为你提供帮助。',
          '你好呀！我是通义千问AI，请问需要什么帮助？'
        ],
        thanks: [
          '不客气！',
          '很高兴能帮到你。',
          '随时为你服务。'
        ],
        farewell: [
          '再见！',
          '有需要再找我。',
          '期待下次交流！'
        ],
        general: [
          '对于你的问题，我的建议是：',
          '这个问题可以从以下方面考虑：',
          '简单来说：',
          '根据情况，我认为：',
          '总结一下：'
        ],
        technical: [
          '技术实现思路：',
          '从开发角度看：',
          '解决方案概述：',
          '关键技术点：',
          '建议实现方式：'
        ]
      },
      
      // Gemini风格 - 创意、全面、多视角
      gemini: {
        greetings: [
          '你好！我是Gemini，由Google DeepMind开发的AI助手。我可以为你提供创意、信息和帮助。',
          '嗨！我是Gemini，很高兴认识你。我喜欢探索新想法并提供多维度的见解。',
          '你好！我是Gemini，一个由Google训练的多模态AI助手。有什么我可以帮助你的吗？'
        ],
        thanks: [
          '非常感谢你的反馈！我很高兴能够帮助到你。',
          '不客气！这是我的荣幸。',
          '很高兴能为你服务！'
        ],
        farewell: [
          '期待下次与你交流！祝你有美好的一天！',
          '再见！希望你有愉快的体验。',
          '很高兴能与你对话！期待下次再聊。'
        ],
        general: [
          '让我从多个角度来思考这个问题：',
          '这个问题涉及到几个有趣的层面，让我们一起探讨：',
          '为了全面理解，我想从历史、现状和未来趋势三个维度来分析：',
          '思考这个问题时，我认为有几个关键因素需要考虑：',
          '这个话题有很多值得探索的方面，比如：'
        ],
        technical: [
          '从技术演进的角度来看，这个问题可以通过以下创新方法解决：',
          '这个技术挑战涉及到前沿研究领域，让我为你梳理一下思路：',
          '从系统设计角度，我推荐考虑以下架构模式：',
          '解决这个问题的关键在于理解底层机制，让我为你拆解一下：'
        ]
      }
    };
    
    // 分析用户输入，确定回复类型和模型
    let selectedModel = 'gpt'; // 默认使用GPT风格
    let responseType = 'general'; // 默认使用通用回复
    
    // 在终端中输出思考过程
    console.log('[思考过程] 分析用户输入内容，识别意图...');
    
    // 关键词识别 - 更复杂的匹配逻辑
    if (content.includes('你好') || content.includes('嗨') || content.includes('您好') || content.includes('早上好') || content.includes('晚上好') || content.includes('下午好')) {
      responseType = 'greetings';
      console.log('[思考过程] 识别到问候意图');
    } else if (content.includes('谢谢') || content.includes('感谢') || content.includes('非常感谢') || content.includes('太感谢了')) {
      responseType = 'thanks';
      console.log('[思考过程] 识别到感谢意图');
    } else if (content.includes('再见') || content.includes('拜拜') || content.includes('下次见') || content.includes('回头见')) {
      responseType = 'farewell';
      console.log('[思考过程] 识别到告别意图');
    } else if (content.includes('代码') || content.includes('编程') || content.includes('开发') || content.includes('算法') || content.includes('实现') || content.includes('技术') || content.includes('API') || content.includes('语言') || content.includes('框架') || content.includes('库')) {
      responseType = 'technical';
      console.log('[思考过程] 识别到技术问题，将使用技术回复');
      
      // 技术问题可以根据内容特征选择不同模型
      if (content.includes('简洁') || content.includes('简单') || content.includes('效率')) {
        selectedModel = 'qwen';
        console.log('[思考过程] 检测到需要简洁回答，选择通义千问风格');
      } else if (content.includes('详细') || content.includes('全面') || content.includes('深入')) {
        selectedModel = 'claude';
        console.log('[思考过程] 检测到需要详细回答，选择Claude风格');
      } else if (content.includes('创意') || content.includes('创新') || content.includes('多维度') || content.includes('角度')) {
        selectedModel = 'gemini';
        console.log('[思考过程] 检测到需要创意回答，选择Gemini风格');
      }
    }
    
    // 随机选择模型（如果不是特定类型的问题）
    if (responseType === 'general') {
      const models = ['gpt', 'claude', 'qwen', 'gemini'];
      selectedModel = models[Math.floor(Math.random() * models.length)];
      console.log('[思考过程] 通用问题，随机选择模型:', selectedModel);
    }
    
    // 根据选择的模型和回复类型获取回复
    const model = selectedModel;
    const responses = modelResponses[model][responseType];
    const selectedResponse = responses[Math.floor(Math.random() * responses.length)];
    
    // 在终端中输出思考过程
    console.log('[思考过程] 确定回复策略 - 模型:', model, '类型:', responseType);
    console.log('[思考过程] 生成回复内容:', selectedResponse);
    
    // 更新AI消息的模型信息
    messages[messages.length - 1].model = model;
    
    // 模拟打字效果，根据不同模型调整打字速度和风格
    let currentIndex = 0;
    
    // 根据模型类型调整打字速度
    let typeSpeed = 50; // 默认打字速度
    if (selectedModel === 'qwen') {
      typeSpeed = 40; // 通义千问风格：更快的打字速度
    } else if (selectedModel === 'claude') {
      typeSpeed = 60; // Claude风格：更慢、更详细的打字速度
    } else if (selectedModel === 'gemini') {
      typeSpeed = 55; // Gemini风格：中等速度，带有时而停顿思考的感觉
    }
    
    // 在终端中输出思考过程
    console.log('[思考过程] 开始模拟', selectedModel, '风格的打字效果，速度：', typeSpeed, 'ms/字符');
    
    const typeInterval = setInterval(() => {
      if (currentIndex <= selectedResponse.length) {
        const messages = this.data.messages;
        const aiMessageIndex = messages.findIndex(msg => msg.id === aiMessageId);
        
        if (aiMessageIndex !== -1) {
          messages[aiMessageIndex].content = selectedResponse.substring(0, currentIndex);
          this.setData({ messages: messages });
          this.scrollToBottom();
        }
        currentIndex++;
      } else {
        // 打字完成
        clearInterval(typeInterval);
        
        const messages = this.data.messages;
        const aiMessageIndex = messages.findIndex(msg => msg.id === aiMessageId);
        
        if (aiMessageIndex !== -1) {
          messages[aiMessageIndex].content = selectedResponse;
          messages[aiMessageIndex].isStreaming = false;
        }
        
        this.setData({
          messages: messages,
          isTyping: false
        });
        
        // 在终端中输出思考过程
        console.log('[思考过程] 回复生成完成，使用模型:', selectedModel);
        
        // 保存到本地缓存
        wx.setStorageSync('chatHistory', messages);
      }
    }, typeSpeed); // 每个字符显示的延迟时间，毫秒
    
    // 添加错误处理：如果模拟过程中出现问题
    setTimeout(() => {
      const messages = this.data.messages;
      const aiMessageIndex = messages.findIndex(msg => msg.id === aiMessageId);
      
      if (aiMessageIndex !== -1 && messages[aiMessageIndex].isStreaming) {
        // 如果超过30秒还在打字状态，终止并显示错误
        clearInterval(typeInterval);
        messages[aiMessageIndex].content = '生成回复超时';
        messages[aiMessageIndex].isStreaming = false;
        messages[aiMessageIndex].isError = true;
        
        // 在终端中输出错误信息
        console.log('[思考过程] 错误：生成回复超时');
        
        this.setData({
          messages: messages,
          isTyping: false
        });
        
        wx.showToast({
          title: '生成超时，请重试',
          icon: 'none'
        });
      }
    }, 30000); // 30秒超时
  },

  // 滚动到底部
  scrollToBottom: function() {
    setTimeout(() => {
      try {
        // 设置scrollToMessage属性（主要滚动方式）
        this.setData({
          scrollToMessage: `msg-${this.data.messages.length - 1}`
        });
        
        // 双重保险：使用selectorQuery获取scroll-view并滚动到底部
        setTimeout(() => {
          wx.createSelectorQuery().in(this)
            .select('.chat-messages')
            .boundingClientRect()
            .exec(res => {
              if (res && res[0]) {
                // 获取scroll-view的scroll-view上下文
                wx.createSelectorQuery().in(this)
                  .select('.chat-messages')
                  .fields({
                    scrollOffset: true,
                    size: true
                  })
                  .exec(res => {
                    if (res && res[0]) {
                      // 使用正确的API方式设置scroll-view的滚动位置
                      this.setData({
                        scrollTop: 999999 // 设置一个很大的值来确保滚动到底部
                      });
                    }
                  });
              }
            });
        }, 100);
      } catch (error) {
        console.error('滚动到底部失败:', error);
      }
    }, 150);
  },

  // 下拉刷新清空历史记录
  onScrollToUpper: function() {
    wx.showModal({
      title: '提示',
      content: '确定要清空所有对话记录吗？',
      success: (res) => {
        if (res.confirm) {
          try {
            wx.removeStorageSync('chatHistory');
            this.setData({
              messages: []
            });
            wx.showToast({
              title: '已清空历史记录',
              icon: 'success'
            });
          } catch (error) {
            console.error('清空历史记录失败:', error);
          }
        }
      }
    });
  }
})