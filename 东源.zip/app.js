App({
  onLaunch: function () {
    // 小程序启动时执行
    console.log('东源AI小程序启动');
    
    // 注意：已移除云开发初始化，使用本地模拟数据实现聊天功能
    // 这样可以避免云环境配置错误导致的问题
    
    console.log('应用启动，使用本地模拟数据模式');
  },
  globalData: {
    userInfo: null
  }
})