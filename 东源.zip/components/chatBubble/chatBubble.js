Component({
  /**
   * 组件的属性列表
   */
  properties: {
    // 角色：user 或 ai
    role: {
      type: String,
      value: 'ai',
      observer: function(newVal) {
        // 可以在这里添加角色变化的处理逻辑
      }
    },
    // 消息内容
    content: {
      type: String,
      value: '',
      observer: function(newVal) {
        // 可以在这里添加内容变化的处理逻辑
      }
    },
    // 是否显示输入中状态
    isTyping: {
      type: Boolean,
      value: false
    },
    // 使用的模型类型（gpt、claude、qwen、gemini等）
    model: {
      type: String,
      value: null,
      observer: function(newVal) {
        // 当模型类型变化时，可以更新组件样式等
        if (newVal && this.data.role === 'ai') {
          // 可以在这里添加根据模型类型调整样式的逻辑
        }
      }
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    // 组件内部数据
  },

  /**
   * 组件的方法列表
   */
  methods: {
    // 组件内部的方法
  }
})