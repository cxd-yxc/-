// 云函数getChatHistory - 查询对话历史
const cloud = require('wx-server-sdk');

// 初始化云开发环境
cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
});

const db = cloud.database();
const _ = db.command;

exports.main = async (event, context) => {
  const { userId, page = 1, size = 10 } = event;
  
  try {
    // 参数校验
    if (!userId) {
      return {
        code: 400,
        message: '缺少userId参数'
      };
    }
    
    // 验证参数合法性
    const pageNum = parseInt(page) || 1;
    const pageSize = parseInt(size) || 10;
    
    if (pageNum < 1 || pageSize < 1 || pageSize > 50) {
      return {
        code: 400,
        message: '分页参数无效'
      };
    }
    
    // 计算跳过的记录数
    const skip = (pageNum - 1) * pageSize;
    
    // 查询总数
    const countResult = await db.collection('chats').where({
      userId: userId
    }).count();
    
    const total = countResult.total;
    
    // 查询对话列表，按更新时间倒序
    const chatResult = await db.collection('chats')
      .where({
        userId: userId
      })
      .orderBy('updateTime', 'desc')
      .skip(skip)
      .limit(pageSize)
      .field({
        chatId: '$_id',
        title: true,
        updateTime: true,
        lastMessage: true
      })
      .get();
    
    // 处理返回数据格式
    const chats = chatResult.data.map(chat => ({
      chatId: chat._id,
      title: chat.title || '未命名对话',
      updateTime: chat.updateTime,
      lastMessage: chat.lastMessage || ''
    }));
    
    return {
      code: 0,
      data: {
        chats: chats,
        total: total
      }
    };
  } catch (error) {
    console.error('查询对话历史失败:', error);
    return {
      code: 500,
      message: '服务器内部错误'
    };
  }
};