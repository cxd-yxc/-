// sendMessage.test.js - sendMessage云函数单元测试
const { main } = require('./index');

// 模拟依赖模块
jest.mock('wx-server-sdk', () => ({
  init: jest.fn(),
  DYNAMIC_CURRENT_ENV: 'dynamic',
  database: jest.fn(() => ({
    serverDate: jest.fn(() => new Date()),
    collection: jest.fn(() => ({
      add: jest.fn(),
      doc: jest.fn(() => ({
        get: jest.fn(),
        update: jest.fn()
      }))
    }))
  }))
}));

jest.mock('axios', () => jest.fn());

const cloud = require('wx-server-sdk');
const axios = require('axios');

describe('sendMessage云函数单元测试', () => {
  let mockContext;
  let mockDb;
  let mockCollection;
  let mockDoc;

  beforeEach(() => {
    // 重置所有模拟
    jest.clearAllMocks();
    
    // 初始化模拟对象
    mockContext = {
      callbackWaitsForEmptyEventLoop: true,
      callback: jest.fn()
    };
    
    // 模拟数据库操作
    mockCollection = {
      add: jest.fn(),
      doc: jest.fn()
    };
    
    mockDoc = {
      get: jest.fn(),
      update: jest.fn()
    };
    
    mockDb = {
      serverDate: jest.fn(() => new Date('2024-01-01')),
      collection: jest.fn(() => mockCollection)
    };
    
    cloud.database.mockReturnValue(mockDb);
    mockCollection.doc.mockReturnValue(mockDoc);
    
    // 设置环境变量
    process.env.DASHSCOPE_API_KEY = 'test-api-key';
  });

  // 模拟流式响应数据
  const createMockStreamResponse = (content) => {
    // 创建一个模拟的Readable流
    const streamChunks = content.split('').map(char => Buffer.from(
      `data: {"output":{"text":"${char}"}}\n\n`
    ));
    
    // 模拟异步迭代器
    const mockAsyncIterator = async function* () {
      for (const chunk of streamChunks) {
        yield chunk;
      }
    };
    
    return {
      data: mockAsyncIterator()
    };
  };

  test('正常发送消息（不带上下文）', async () => {
    // 准备测试数据
    const event = {
      userId: 'test-user-id',
      content: '你好，请介绍一下自己',
      contextId: ''
    };
    
    // 模拟数据库操作
    mockCollection.add.mockResolvedValue({ _id: 'new-chat-id' });
    mockDoc.update.mockResolvedValue({});
    
    // 模拟axios流式响应
    axios.mockResolvedValue(createMockStreamResponse('你好！我是东源AI助手。'));
    
    // 执行测试
    const result = await main(event, mockContext);
    
    // 验证结果
    expect(result.code).toBe(0);
    expect(result.data).toHaveProperty('reply', '你好！我是东源AI助手。');
    expect(result.data).toHaveProperty('contextId', 'new-chat-id');
    expect(result.data).toHaveProperty('chatId', 'new-chat-id');
    
    // 验证数据库操作
    expect(mockCollection.add).toHaveBeenCalledTimes(1);
    expect(mockDoc.update).toHaveBeenCalledTimes(1);
    
    // 验证进度回调被调用
    expect(mockContext.callback).toHaveBeenCalledTimes(14); // 14个字符的回复
  });

  test('正常发送消息（带上下文）', async () => {
    // 准备测试数据
    const event = {
      userId: 'test-user-id',
      content: '今天天气怎么样？',
      contextId: 'existing-chat-id'
    };
    
    // 模拟现有对话数据
    const existingChatData = {
      userId: 'test-user-id',
      title: '之前的对话',
      messages: [
        { role: 'user', content: '你好', timestamp: new Date() },
        { role: 'assistant', content: '你好！', timestamp: new Date() }
      ],
      context: [],
      createdAt: new Date(),
      updateTime: new Date()
    };
    
    // 设置模拟返回值
    mockDoc.get.mockResolvedValue({ data: existingChatData });
    mockDoc.update.mockResolvedValue({});
    
    // 模拟axios流式响应
    axios.mockResolvedValue(createMockStreamResponse('我无法获取实时天气信息。'));
    
    // 执行测试
    const result = await main(event, mockContext);
    
    // 验证结果
    expect(result.code).toBe(0);
    expect(result.data.reply).toBe('我无法获取实时天气信息。');
    expect(result.data.contextId).toBe('existing-chat-id');
    
    // 验证数据库操作
    expect(mockCollection.add).not.toHaveBeenCalled(); // 不应该创建新对话
    expect(mockDoc.get).toHaveBeenCalledTimes(1);
    expect(mockDoc.update).toHaveBeenCalledTimes(1);
  });

  test('清空对话功能', async () => {
    // 准备测试数据
    const event = {
      userId: 'test-user-id',
      content: '清空对话',
      contextId: 'existing-chat-id'
    };
    
    // 执行测试
    const result = await main(event, mockContext);
    
    // 验证结果
    expect(result.code).toBe(0);
    expect(result.data.reply).toBe('已清空对话，开始新的对话吧！');
    expect(result.data.contextId).toBe('');
    expect(result.data.chatId).toBe('');
    expect(result.isNewChat).toBe(true);
    
    // 验证没有数据库操作
    expect(mockCollection.add).not.toHaveBeenCalled();
    expect(mockDoc.get).not.toHaveBeenCalled();
    expect(mockDoc.update).not.toHaveBeenCalled();
  });

  test('空内容输入', async () => {
    // 准备测试数据（空内容）
    const event = {
      userId: 'test-user-id',
      content: '',
      contextId: ''
    };
    
    // 执行测试
    const result = await main(event, mockContext);
    
    // 验证结果
    expect(result.code).toBe(400);
    expect(result.message).toBe('缺少必要参数');
  });

  test('缺少userId参数', async () => {
    // 准备测试数据（缺少userId）
    const event = {
      content: '测试消息',
      contextId: ''
    };
    
    // 执行测试
    const result = await main(event, mockContext);
    
    // 验证结果
    expect(result.code).toBe(400);
    expect(result.message).toBe('缺少必要参数');
  });

  test('非法userId访问对话', async () => {
    // 准备测试数据
    const event = {
      userId: 'wrong-user-id',
      content: '测试消息',
      contextId: 'existing-chat-id'
    };
    
    // 模拟现有对话数据（属于其他用户）
    const existingChatData = {
      userId: 'test-user-id',
      title: '其他用户的对话',
      messages: [],
      context: [],
      createdAt: new Date(),
      updateTime: new Date()
    };
    
    // 设置模拟返回值
    mockDoc.get.mockResolvedValue({ data: existingChatData });
    
    // 执行测试
    const result = await main(event, mockContext);
    
    // 验证结果
    expect(result.code).toBe(403);
    expect(result.message).toBe('无权限访问此对话');
  });

  test('API调用失败（重试机制）', async () => {
    // 准备测试数据
    const event = {
      userId: 'test-user-id',
      content: '测试消息',
      contextId: ''
    };
    
    // 模拟数据库操作
    mockCollection.add.mockResolvedValue({ _id: 'new-chat-id' });
    
    // 模拟第一次API调用失败，第二次成功
    axios.mockRejectedValueOnce(new Error('API调用失败'))
      .mockResolvedValueOnce(createMockStreamResponse('成功的回复'));
    
    // 执行测试
    const result = await main(event, mockContext);
    
    // 验证结果
    expect(result.code).toBe(0);
    expect(result.data.reply).toBe('成功的回复');
    
    // 验证axios被调用了两次（第一次失败，第二次成功）
    expect(axios).toHaveBeenCalledTimes(2);
  });

  test('环境变量未配置', async () => {
    // 准备测试数据
    const event = {
      userId: 'test-user-id',
      content: '测试消息',
      contextId: ''
    };
    
    // 移除API密钥环境变量
    delete process.env.DASHSCOPE_API_KEY;
    
    // 模拟数据库操作
    mockCollection.add.mockResolvedValue({ _id: 'new-chat-id' });
    
    // 执行测试并验证错误
    await expect(main(event, mockContext)).rejects.toThrow('通义千问API密钥未配置');
  });
});