// 云函数sendMessage - AI对话核心功能（支持流式响应）
const cloud = require('wx-server-sdk');
const axios = require('axios');
const { Readable } = require('stream');

// 初始化云开发环境
cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
});

const db = cloud.database();
const MAX_CONTEXT_ROUNDS = 10; // 最多保留10轮对话

// 通义千问API流式调用函数
async function callQwenApiStream({ userInput, context = [], onChunk }) {
  const apiKey = process.env.DASHSCOPE_API_KEY;
  
  if (!apiKey) {
    throw new Error('通义千问API密钥未配置');
  }
  
  // 构建请求消息体
  const messages = [...context];
  messages.push({
    role: 'user',
    content: userInput
  });
  
  // 使用axios的流式请求
  const response = await axios({
    method: 'post',
    url: 'https://dashscope.aliyuncs.com/api/v1/services/aigc/text-generation/generation',
    headers: {
      'Authorization': `Bearer ${apiKey}`,
      'Content-Type': 'application/json'
    },
    data: {
      model: 'qwen-turbo',
      input: {
        messages: messages
      },
      parameters: {
        max_tokens: 2000,
        temperature: 0.7,
        top_p: 0.9,
        top_k: 40,
        stream: true // 启用流式响应
      }
    },
    responseType: 'stream'
  });
  
  let fullReply = '';
  
  // 处理流式响应
  for await (const chunk of response.data) {
    try {
      const chunkStr = chunk.toString();
      // 处理SSE格式的数据流
      const lines = chunkStr.split('\n').filter(line => line.trim().length > 0);
      
      for (const line of lines) {
        if (line.startsWith('data:')) {
          const dataStr = line.substring(5).trim();
          if (dataStr === '[DONE]') {
            break;
          }
          
          try {
            const data = JSON.parse(dataStr);
            if (data.output && data.output.text) {
              const delta = data.output.text;
              fullReply += delta;
              // 调用回调函数推送部分回复
              onChunk(delta);
            }
          } catch (parseError) {
            console.warn('解析响应数据失败:', parseError);
          }
        }
      }
    } catch (error) {
      console.error('处理响应块失败:', error);
    }
  }
  
  return fullReply;
}

exports.main = async (event, context) => {
  const { userId, content, contextId } = event;
  
  // 设置响应格式为流式
  context.callbackWaitsForEmptyEventLoop = false;
  
  try {
    // 参数校验
    if (!userId || !content) {
      return {
        code: 400,
        message: '缺少必要参数'
      };
    }
    
    // 检查是否需要清空对话
    if (content === '清空对话') {
      return {
        code: 0,
        data: {
          reply: '已清空对话，开始新的对话吧！',
          contextId: '',
          chatId: ''
        },
        isNewChat: true
      };
    }
    
    let chatInfo;
    let messages = [];
    const now = db.serverDate();
    
    if (!contextId) {
      // 创建新对话
      const title = content.length > 15 ? content.substring(0, 15) + '...' : content;
      
      const chatResult = await db.collection('chats').add({
        data: {
          userId: userId,
          title: title,
          messages: [],
          context: [],
          createdAt: now,
          updateTime: now
        }
      });
      
      chatInfo = {
        chatId: chatResult._id,
        contextId: chatResult._id
      };
    } else {
      // 查询现有对话
      const chatDoc = await db.collection('chats').doc(contextId).get();
      
      if (!chatDoc.data || chatDoc.data.userId !== userId) {
        return {
          code: 403,
          message: '无权限访问此对话'
        };
      }
      
      chatInfo = {
        chatId: contextId,
        contextId: contextId
      };
      messages = chatDoc.data.messages || [];
      
      // 获取现有上下文
      const existingContext = chatDoc.data.context || [];
      messages = [...existingContext, ...messages];
    }
    
    // 构建API调用的上下文格式
    const apiContext = messages.map(msg => ({
      role: msg.role,
      content: msg.content
    }));
    
    // 定义流式回调函数
    const onProgressUpdate = (chunk) => {
      try {
        // 通过云函数上下文推送进度更新
        context.callback(JSON.stringify({
          code: 100, // 100表示流式更新
          data: {
            delta: chunk, // 返回增量内容
            contextId: chatInfo.contextId,
            chatId: chatInfo.chatId
          }
        }));
      } catch (error) {
        console.error('推送进度更新失败:', error);
      }
    };
    
    // 调用通义千问API流式接口，带重试机制
    let aiReply;
    let apiCallSuccess = false;
    let retryCount = 0;
    const MAX_RETRY = 1;
    
    while (!apiCallSuccess && retryCount <= MAX_RETRY) {
      try {
        aiReply = await callQwenApiStream({
          userInput: content,
          context: apiContext,
          onChunk: onProgressUpdate
        });
        apiCallSuccess = true;
      } catch (apiError) {
        retryCount++;
        if (retryCount > MAX_RETRY) {
          throw apiError;
        }
        console.log(`API调用失败，正在重试... (${retryCount}/${MAX_RETRY})`);
        await new Promise(resolve => setTimeout(resolve, 1000));
      }
    }
    
    // 更新对话记录
    const newUserMessage = {
      role: 'user',
      content: content,
      timestamp: now
    };
    
    const newAiMessage = {
      role: 'assistant',
      content: aiReply,
      timestamp: now
    };
    
    // 添加新消息
    messages.push(newUserMessage, newAiMessage);
    
    // 优化上下文管理
    if (messages.length > MAX_CONTEXT_ROUNDS * 2) {
      messages = messages.slice(-MAX_CONTEXT_ROUNDS * 2);
    }
    
    // 存储对话记录
    await db.collection('chats').doc(chatInfo.chatId).update({
      data: {
        messages: messages,
        context: apiContext.slice(-MAX_CONTEXT_ROUNDS * 2),
        updateTime: now,
        lastMessage: content
      }
    });
    
    // 返回最终结果
    return {
      code: 0,
      data: {
        reply: aiReply,
        contextId: chatInfo.contextId,
        chatId: chatInfo.chatId
      }
    };
  } catch (error) {
    console.error('发送消息失败:', error);
    
    let errorMessage = '服务器内部错误';
    if (error.message) {
      errorMessage = error.message;
    }
    
    // 返回错误信息
    return {
      code: 500,
      message: errorMessage
    };
  }
};