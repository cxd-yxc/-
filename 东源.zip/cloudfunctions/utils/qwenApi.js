// 通义千问API对接工具函数
const axios = require('axios');

/**
 * 调用通义千问API获取AI回复
 * @param {Object} params - 参数对象
 * @param {string} params.userInput - 用户输入
 * @param {Array} params.context - 上下文数组 [{role: 'user', content: 'xxx'}, {role: 'assistant', content: 'xxx'}]
 * @returns {Promise<string>} - AI回复内容
 */
async function callQwenApi({ userInput, context = [] }) {
  try {
    // 从环境变量获取API密钥
    const apiKey = process.env.DASHSCOPE_API_KEY;
    
    if (!apiKey) {
      throw new Error('通义千问API密钥未配置');
    }
    
    // 构建请求消息体
    const messages = [...context];
    
    // 添加最新的用户消息
    messages.push({
      role: 'user',
      content: userInput
    });
    
    // 调用通义千问API
    const response = await axios({
      method: 'post',
      url: 'https://dashscope.aliyuncs.com/api/v1/services/aigc/text-generation/generation',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      },
      data: {
        model: 'qwen-turbo',
        input: {
          messages: messages
        },
        parameters: {
          max_tokens: 2000,
          temperature: 0.7,
          top_p: 0.9,
          top_k: 40
        }
      }
    });
    
    // 检查API返回结果
    if (response.data && response.data.output && response.data.output.text) {
      return response.data.output.text;
    } else {
      throw new Error('API返回格式异常');
    }
  } catch (error) {
    console.error('通义千问API调用失败:', error);
    
    // 处理不同类型的错误
    if (error.response) {
      // API返回错误状态码
      if (error.response.status === 401) {
        throw new Error('API密钥无效');
      } else if (error.response.status === 429) {
        throw new Error('API调用频率超限，请稍后再试');
      }
      throw new Error(`API调用失败: ${error.response.data?.error?.message || '未知错误'}`);
    } else if (error.request) {
      // 请求发送失败
      throw new Error('网络连接失败，请检查网络');
    } else {
      // 其他错误
      throw error;
    }
  }
}

module.exports = {
  callQwenApi
};