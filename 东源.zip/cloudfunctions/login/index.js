// 云函数login
const cloud = require('wx-server-sdk');
const axios = require('axios');

// 初始化云开发环境
cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
});

const db = cloud.database();

// 获取微信小程序AppID和AppSecret（从环境变量读取或硬编码）
const APPID = process.env.WX_APPID || ''; // 在云开发环境变量中配置
const APPSECRET = process.env.WX_APPSECRET || '';

exports.main = async (event, context) => {
  const { wxCode } = event;
  
  try {
    // 参数校验
    if (!wxCode) {
      return {
        code: 400,
        message: '缺少wxCode参数'
      };
    }
    
    // 调用微信登录接口获取openid
    const wxLoginUrl = `https://api.weixin.qq.com/sns/jscode2session?appid=${APPID}&secret=${APPSECRET}&js_code=${wxCode}&grant_type=authorization_code`;
    const loginResult = await axios.get(wxLoginUrl);
    
    // 检查是否获取成功
    if (loginResult.data.errcode) {
      return {
        code: 500,
        message: `微信登录失败: ${loginResult.data.errmsg}`
      };
    }
    
    const { openid } = loginResult.data;
    
    // 查询用户是否已存在
    const userResult = await db.collection('users').where({
      _id: openid
    }).get();
    
    const now = db.serverDate();
    let userInfo = {
      userId: openid,
      wxNickname: '',
      wxAvatar: ''
    };
    
    if (userResult.data.length > 0) {
      // 更新用户最后登录时间
      await db.collection('users').doc(openid).update({
        data: {
          lastLoginTime: now
        }
      });
      
      // 获取现有用户信息
      const existingUser = userResult.data[0];
      userInfo.wxNickname = existingUser.nickname || '';
      userInfo.wxAvatar = existingUser.avatarUrl || '';
    } else {
      // 创建新用户记录
      await db.collection('users').add({
        data: {
          _id: openid,
          nickname: '',
          avatarUrl: '',
          createdAt: now,
          lastLoginTime: now
        }
      });
    }
    
    return {
      code: 0,
      data: userInfo
    };
  } catch (error) {
    console.error('登录失败:', error);
    return {
      code: 500,
      message: '服务器内部错误',
      error: error.message
    };
  }
};